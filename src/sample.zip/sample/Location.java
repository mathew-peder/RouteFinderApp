package sample;

/**
 * @author Mathew Peder
 * <p>
 * Applied Computing - 20073231
 */
public class Location
{

    private String id;
    private String type;

    public Location(String id, String type)
    {
        setId( id );
        setType( type );
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }







}
