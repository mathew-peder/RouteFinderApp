package sample;

import java.util.ArrayList;

/**
 * @author Mathew Peder
 * <p>
 * Applied Computing - 20073231
 */
public class GraphNode<Loc> {
    public Loc data;
    public ArrayList<Loc> Location;


    public GraphNode(Loc data){
        this.setAdjList( new ArrayList<>() );
        this.setData( data );
    }

    public ArrayList<Loc> getAdjList()
    {
        return Location;
    }

    public void setAdjList(ArrayList<Loc> adjList)
    {
        this.Location = adjList;
    }


    public Loc getData()
    {
        return data;
    }

    public void setData(Loc data)
    {
        this.data = data;
    }

}