package sample;

/**
 * @author Mathew Peder
 * <p>
 * Applied Computing - 20073231
 */
public class Road extends Location
{

    private String roadName;
    private int distance;

    public Road(String roadName, String id, String type, int distance)
    {
        super(id, type);
        setRoadName( roadName );
        setDistance( distance );
    }


    public String getRoadName()
    {
        return roadName;
    }


    public void setRoadName(String roadname)
    {
        this.roadName = roadname;
    }

    public int getDistance()
    {
        return distance;
    }

    public void setDistance(int distance)
    {
        this.distance = distance;
    }
}
