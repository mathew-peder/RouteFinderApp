package sample;

/**
 * @author Mathew Peder
 * <p>
 * Applied Computing - 20073231
 */


public class Landmark extends Location

{

    private String landmarkName;

    public Landmark(String landmarkname, String id, String type)
    {
        super(id, type);
        setLandmarkName( landmarkname );
    }


    public String getLandmarkName()
    {
        return landmarkName;
    }


    public void setLandmarkName(String landmarkName)
    {
        this.landmarkName = landmarkName;
    }
}
