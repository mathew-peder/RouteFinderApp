package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class Controller
{

    private ArrayList<GraphNode> nodeCollection = new ArrayList<GraphNode>();


    @FXML
    BorderPane borderPane;
    @FXML
    SplitPane splitPane;
    @FXML
    Button navigateButton;
    @FXML
    TextField startText;
    @FXML
    TextField finishText;
    @FXML
    ScrollBar routeScroll;
    @FXML
    TextField nameText;
    @FXML
    TextField idText;
    @FXML
    TextField typeText;
    @FXML
    TextField distanceText;
    @FXML
    Button addNewbutton;
    @FXML
    Button loadCsvbutton;



    private File save=new File("/home/mat/Downloads/Assignment2/src/sample/save.txt");

    public void loadCSV(ActionEvent actionEvent){


        try {
            FileInputStream fis = new FileInputStream  (save);
            BufferedReader br=new BufferedReader(new InputStreamReader(fis));
            String str;

            do {
                str = br.readLine();
                if(str!=null) {
                    String[] tokens = str.split(",");
                    //System.out.println(str);
                    if(tokens[0].equalsIgnoreCase( "Landmark" ))
                    {
                        String type = tokens[0];
                        String id = tokens[1];
                        String name = tokens[2];

                        Landmark newLandmark = new Landmark(name, id, type);
                        GraphNode graphNode = new GraphNode( newLandmark );
                        nodeCollection.add( graphNode );


                    }
                    else if(tokens[0].equalsIgnoreCase( "Road" ))
                    {
                        String type = tokens[0];
                        String id = tokens[1];
                        String name = tokens[2];
                        int distance = Integer.parseInt(tokens[3]);

                        Road newRoad = new Road(name, id, type, distance);
                        GraphNode graphNode = new GraphNode( newRoad );
                        nodeCollection.add( graphNode );
                    }
                    else
                    {
                        String id = tokens[1];
                        GraphNode landmark = searchLandmarkid( id );


                        for(int i =2;i<tokens.length;i+=1)
                        {
                            GraphNode road = searchRoadid( tokens[i] );
                            landmark.getAdjList().add( road );
                            road.getAdjList().add( landmark );
                        }
                        //landmark.getAdjList().add( tokens );
                    }
                }

            }while(str!=null);

            br.close();


            for(int i=0; i < nodeCollection.size(); i+=1 )
            {
                System.out.println(nodeCollection.get( i ).getData());

                for(int j=0; j < nodeCollection.size(); j+=1)
                {
                    System.out.println(nodeCollection.get( i ).getAdjList().get( j ));
                }
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    public GraphNode searchLandmarkid(String id)
    {
        for(int i=0; i < nodeCollection.size(); i+=1 )
        {
            try
            {
                GraphNode<Landmark> landmark = nodeCollection.get( i );

                if (id.equalsIgnoreCase( landmark.getData().getId() ))
                {
                    System.out.println( "Found Location " + landmark.getData().getLandmarkName() );

                    return landmark;
                }
            }
            catch(Exception e)
            {
            }

        }
        System.out.println( "Landmark ID not found" );

        return null;
    }


    public GraphNode searchRoadid(String id)
    {
        for(int i=0; i < nodeCollection.size(); i+=1 )
        {
            try
            {
                GraphNode<Road> road = nodeCollection.get( i );

                if (id.equalsIgnoreCase( road.getData().getId() ))
                {
                    System.out.println( "Found Location " + road.getData().getRoadName());

                    return road;
                }
            }
            catch(Exception e)
            {
            }

        }
        System.out.println( "Landmark ID not found" );

        return null;
    }



    public void navigateTo(ActionEvent event)
    {
        startText.getText();
        finishText.getText();
        if(startText.getText() != null && finishText.getText() != null )
        {
            GraphNode start = searchStart();
            GraphNode finish = searchFinish();
            findPath(start, finish);
        }

    }


    public GraphNode searchStart()
    {
        for(int i=0; i < nodeCollection.size(); i+=1 )
        {
            try
            {
                GraphNode<Landmark> landmark = nodeCollection.get( i );

                if (startText.getText().equalsIgnoreCase( landmark.getData().getLandmarkName() ))
                {
                    System.out.println( "Found Location " + landmark.getData().getLandmarkName() );

                    return landmark;
                }
            }
            catch(Exception e)
            {
            }

        }
        System.out.println( "Please enter a valid landmark name for start of route" );

        return null;
    }

    public GraphNode searchFinish()
    {
        for(int i=0; i < nodeCollection.size(); i+=1 )
        {
            try
            {


                GraphNode<Landmark> landmark = nodeCollection.get( i );

                if (finishText.getText().equalsIgnoreCase( landmark.getData().getLandmarkName() ))
                {
                    System.out.println( "Found Location " + landmark.getData().getLandmarkName() );

                    return landmark;
                }
            }
            catch(Exception e)
            {
            }

        }
        System.out.println( "Please enter a valid landmark name for end of route" );

        return null;
    }

    public void findPath(GraphNode start, GraphNode finish)
    {
        if(start != null && finish != null)
        {

        }

    }



    public void shortestRoute(ActionEvent event)
    {
        //traverseGraphBreadthFirst(  );

    }


    public void scrollRoute(MouseEvent mouseEvent)
    {

    }


    public void addNew(ActionEvent actionEvent)
    {
        nameText.getText();
        idText.getText();
        typeText.getText();
        distanceText.getText();



        if(nameText.getText() != null && idText.getText() != null && typeText.getText() != null)
        {
            if(typeText.getText().equalsIgnoreCase( "Landmark" ))
            {
                Landmark newLandmark = new Landmark(nameText.getText(), idText.getText(), typeText.getText());
                GraphNode graphNode = new GraphNode( newLandmark );
                nodeCollection.add( graphNode );
                saveTocsv();

            }

            else if (distanceText.getText() != null && typeText.getText().equalsIgnoreCase( "Road"))
            {
                int distance = Integer.parseInt(distanceText.getText());
                Road newRoad = new Road(nameText.getText(), idText.getText(), typeText.getText(), distance);
                GraphNode graphNode = new GraphNode( newRoad );
                nodeCollection.add( graphNode );

                saveTocsv();
            }
        }
        for(int i=0; i < nodeCollection.size(); i+=1 )
        {
            System.out.println(nodeCollection.get( i ));
        }

    }

    public void saveTocsv()
    {
        try
        {
            FileWriter fw = new FileWriter(save.getAbsoluteFile(), true);
            String str = "\n" + typeText.getText() +","+ idText.getText() +","+ nameText.getText();
            if(typeText.getText().equalsIgnoreCase( "Road" ))
            {
             str = str +","+  distanceText.getText();
            }
            fw.append( str );
            fw.close();
        }
        catch(Exception e)
        {
            System.out.println( e );
        }

    }



    public static void traverseGraphDepthFirst(GraphNode<?> from, List<GraphNode<?>> encountered ){
        System.out.println(from.data);
        if(encountered==null) encountered=new ArrayList<>(); //First node so create new (empty) encountered list
        encountered.add(from);
        for(GraphNode<?> adjNode: from.getAdjList())
            if(!encountered.contains(adjNode)) traverseGraphDepthFirst(adjNode, encountered );


//    public static void traverseGraphBreadthFirst(List<GraphNode<?>> agenda, List<GraphNode<?>> encountered ){
//        if(agenda.isEmpty()) return;
//        GraphNode<?> next=agenda.remove(0);
//        System.out.println(next.data);
//        if(encountered==null) encountered=new ArrayList<>();
//        encountered.add(next);
//        for(GraphNode<?> adjNode : next.getAdjList())
//            if(!encountered.contains(adjNode) && !agenda.contains(adjNode)) agenda.add(adjNode);
//        traverseGraphBreadthFirst(agenda, encountered ); //Tail call
//    }
}
